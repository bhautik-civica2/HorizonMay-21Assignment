git init
git -m commit
git checkout
git remote origin push
git pull
git clone