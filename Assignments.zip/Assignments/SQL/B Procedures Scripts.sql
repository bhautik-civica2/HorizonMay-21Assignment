
use Training;

--1st Procedure
CREATE OR ALTER PROCEDURE Learning.FirstProcedure
AS
BEGIN
	select C.Cust_Code, C.Cust_Name, C.Cust_Country, A.Agent_Code
	from Learning.Customer C
	join Learning.Agent A on C.AgentID = A.AgentID;
END

EXEC Learning.FirstProcedure;

--2nd Procedure
CREATE OR ALTER PROCEDURE Learning.SecondProcedure
AS
BEGIN

	declare @AgentID int = 0
	set @AgentID = 8

	select @AgentID
	print @AgentID

	select C.Cust_Code, C.Cust_Name, C.Cust_Country, A.Agent_Code
	from Learning.Customer C
	join Learning.Agent A on C.AgentID = A.AgentID
	where A.AgentID = @AgentID;
END

EXEC Learning.SecondProcedure;

--3rd Procedure
CREATE OR ALTER PROCEDURE Learning.ThirdProcedure @grade int
AS
BEGIN

	select @grade
	--print @grade

	select C.Cust_Code, C.Cust_Name, C.Working_Area, C.Cust_Country, C.Phone_No, A.Agent_Code
	from Learning.Customer C
	join Learning.Agent A on C.AgentID = A.AgentID
	where C.Grade = @grade;
END

EXEC Learning.ThirdProcedure 2;

--4th Procedure
CREATE OR ALTER PROCEDURE Learning.FourthProcedure @grade int, @AgentID int
AS
BEGIN

	select @grade, @AgentID
	print @grade
	print @AgentID

	select C.Cust_Code, C.Cust_Name, C.Working_Area, C.Cust_Country, C.Phone_No, A.Agent_Code
	from Learning.Customer C
	join Learning.Agent A on C.AgentID = A.AgentID
	where C.Grade = @grade and C.AgentID = @AgentID;
END

EXEC Learning.FourthProcedure 1, 10;




--Display table
SELECT * FROM Learning.Customer;
SELECT * FROM Learning.Agent; 

