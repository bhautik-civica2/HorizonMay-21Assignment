
use Training;

--Create table
BEGIN
IF OBJECT_ID('Training.Learning.Agent', 'U') IS NOT NULL DROP TABLE Training.Learning.Agent;
CREATE TABLE Learning.Agent (
    AgentID int NOT NULL PRIMARY KEY,
	Agent_Code char(6) UNIQUE,
	Agent_Name char(40) NOT NULL,
	Working_Area char(35),
	Commission decimal (10,2),
	Phone_No char(15),
	Country varchar(25),

); 
END;

--Insert Data
BEGIN
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (01, 'A001', 'Subbarao', 'Bangalore', 0.14, '077-12346674');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (02, 'A002', 'Mukesh', 'Mumbai', 0.11, '029-12358964');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (03, 'A003', 'Alex', 'London', 0.13, '075-12458969');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (04, 'A004', 'Ivan', 'Torento', 0.15, '008-22544166');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (05, 'A005', 'Anderson', 'Brisban', 0.13, '045-21447739');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (06, 'A006', 'McDen', 'London', 0.15, '078-22255588');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (07, 'A007', 'Ramasundar', 'Bangalore', 0.15, '077-25814763');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (08, 'A008', 'Alford', 'New York', 0.12, '044-25874365');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (09, 'A009', 'Benjamin', 'Hampshair', 0.11, '008-22536178');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (10, 'A010', 'Santakumar', 'Chennai', 0.14, '007-22388644');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (11, 'A011', 'Ravi Kumar', 'Bangalore', 0.15, '077-45625874');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (12, 'A012', 'Lucida', 'San Jose', 0.12, '044-52981425');
END;


--Display Table
SELECT * FROM Learning.Agent;

--delete from Learning.Agent;
--UPDATE Learning.Agent SET Country = '';
