
use Training

/* Question 2 */

--Q.1
select * from Learning.Customer where Cust_City = 'Bangalore';

--Q.2
select * from Learning.Customer where Cust_Country = 'Canada' OR Cust_Country = 'UK';

--Q.3
select * from Learning.Customer where Cust_Country NOT IN ('India');

--Q.4
select * from Learning.Customer where Cust_Name like 'M%';

--Q.5
select * from Learning.Customer where Opening_Amt > 7000;

--Q.6
select * from Learning.Customer where Opening_Amt BETWEEN 4000 and 6000;


--Q.7
select * from Learning.Customer where ( (Opening_Amt + Receive_Amt) - Payment_Amt ) > 3000;

--Q.8
select * from Learning.Agent A, Learning.Customer C
where A.AgentID = C.AgentID and Opening_Amt > 5000;

--Q.9
select A.Agent_Name, count(*) from Learning.Agent A
join Learning.Customer C
on A.AgentID = C.AgentID
group by a.Agent_Name;

--Q.10
select * From Learning.Agent A,learning.Customer C
Where A.AgentID = C.AgentID
And (cust_city = 'Bangalore' or cust_city = 'Mumbai')
And opening_amt > 5000;

--Display table
SELECT * FROM Learning.Customer;
SELECT * FROM Learning.Agent;


/* Question 3 */

--Q.1
update Learning.Agent
set Commission = 0.18
from Learning.Agent A join Learning.Customer on A.AgentID = Customer.AgentID 
where Customer.Opening_Amt > 8000;

--Q.2
update Learning.Customer
set Phone_No = '99999'
from Learning.Customer C join Learning.Agent A on A.AgentID = C.AgentID 
where C.Cust_Name like 'M%' and A.Agent_Name = 'Alford';


--Q.3
update Learning.Customer
set Working_Area = A.Working_Area
from Learning.Customer C join Learning.Agent A on A.AgentID = C.AgentID

--Display table
SELECT * FROM Learning.Customer;
SELECT * FROM Learning.Agent;


/* Question 4 */

--Q.1
delete Learning.Customer
from Learning.Customer C inner join Learning.Agent A on C.AgentID = A.AgentID
where A.Agent_Name = 'Alex';

--Q.2
delete from Learning.Customer where Outstanding_Amt < 5000;

--Display table
SELECT * FROM Learning.Customer;
SELECT * FROM Learning.Agent;

/* Question 5 */

truncate table Learning.Customer;

truncate table Learning.Agent;  /* cause error due to being referenced by a FOREIGN KEY constraint. */

--Display table
SELECT * FROM Learning.Customer;
SELECT * FROM Learning.Agent;

/* Question 6 */

--Agent Table Data
BEGIN
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (01, 'A001', 'Subbarao', 'Bangalore', 0.14, '077-12346674');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (02, 'A002', 'Mukesh', 'Mumbai', 0.11, '029-12358964');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (03, 'A003', 'Alex', 'London', 0.13, '075-12458969');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (04, 'A004', 'Ivan', 'Torento', 0.15, '008-22544166');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (05, 'A005', 'Anderson', 'Brisban', 0.13, '045-21447739');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (06, 'A006', 'McDen', 'London', 0.15, '078-22255588');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (07, 'A007', 'Ramasundar', 'Bangalore', 0.15, '077-25814763');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (08, 'A008', 'Alford', 'New York', 0.12, '044-25874365');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (09, 'A009', 'Benjamin', 'Hampshair', 0.11, '008-22536178');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (10, 'A010', 'Santakumar', 'Chennai', 0.14, '007-22388644');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (11, 'A011', 'Ravi Kumar', 'Bangalore', 0.15, '077-45625874');
INSERT INTO Learning.Agent(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No) VALUES (12, 'A012', 'Lucida', 'San Jose', 0.12, '044-52981425');
END;

--Customer Table Data

BEGIN
INSERT INTO Learning.Customer VALUES (01, 'C00001', 'Micheal', 'New York', 'New York', 'USA', 2, 3000, 5000, 2000, 6000, 'CCCCCCC', 8);
INSERT INTO Learning.Customer VALUES (02, 'C00002', 'Bolt', 'New York', 'New York', 'USA', 3, 5000, 7000, 9000, 3000, 'DDNRDRH', 8);
INSERT INTO Learning.Customer VALUES (03, 'C00003', 'Martin', 'Torento', 'Canada', 'USA', 2, 8000, 7000, 7000, 8000, 'MJYURFD', 10);
INSERT INTO Learning.Customer VALUES (04, 'C00004', 'Winston', 'Brisban', 'Brisban', 'Australia', 1, 5000, 8000, 7000, 6000, 'AAAAAAA', 11);
INSERT INTO Learning.Customer VALUES (05, 'C00005', 'Sasikant', 'Mumbai', 'Mumbai', 'India', 1, 7000, 11000, 7000, 11000, 'CCCCCCC', 2);

INSERT INTO Learning.Customer VALUES (06, 'C00006', 'Shilton', 'Torento', 'Torento York', 'Canada', 1, 1000, 7000, 6000, 11000, 'DDDDDDD', 10);
INSERT INTO Learning.Customer VALUES (07, 'C00007', 'Ramanathan', 'Chennai', 'Chennai', 'India', 1, 7000, 11000, 9000, 9000, 'GHRDWSD', 10);
INSERT INTO Learning.Customer VALUES (08, 'C00008', 'Karolina', 'Torento', 'Torento', 'Canada', 1, 7000, 7000, 9000, 5000, 'HJKORED', 10);
INSERT INTO Learning.Customer VALUES (09, 'C00009', 'Ramesh', 'Mumbai', 'Mumbai', 'India', 3, 8000, 7000, 3000, 12000, 'Phone No', 2);
INSERT INTO Learning.Customer VALUES (10, 'C00010', 'Charles', 'Hampshair', 'Hampshair', 'UK', 3, 6000, 4000, 5000, 5000, 'MMMMMMM', 9);

INSERT INTO Learning.Customer VALUES (11, 'C00011', 'Sundariya', 'Chennai', 'Chennai', 'India', 3, 7000, 11000, 7000, 11000, 'PPHGRTS', 10);
INSERT INTO Learning.Customer VALUES (12, 'C00012', 'Steven', 'San Jose', 'San Jose', 'USA', 1, 5000, 7000, 9000, 3000, 'KRFYGJK', 12);
INSERT INTO Learning.Customer VALUES (13, 'C00013', 'Holmes', 'London', 'London', 'UK', 2, 6000, 5000, 7000, 4000, 'BBBBBBB', 3);
INSERT INTO Learning.Customer VALUES (14, 'C00014', 'Rangarappa', 'Bangalore', 'Bangalore', 'India', 2, 8000, 11000, 7000, 12000, 'AAAATGF', 1);
INSERT INTO Learning.Customer VALUES (15, 'C00015', 'Stuart', 'London', 'London', 'UK', 1, 6000, 8000, 3000, 11000, 'GFSGERS', 3);

INSERT INTO Learning.Customer VALUES (16, 'C00016', 'Venkatpati', 'Bangalore', 'Bangalore', 'India', 2, 8000, 11000, 7000, 12000, 'JRTVFDD', 7);
INSERT INTO Learning.Customer VALUES (17, 'C00017', 'Srinivas', 'Bangalore', 'Bangalore', 'India', 2, 8000, 4000, 3000, 9000, 'AAAAAAB', 7);
INSERT INTO Learning.Customer VALUES (18, 'C00018', 'Fleming', 'Brisban', 'Brisban', 'Australia', 2, 7000, 7000, 9000, 5000, 'NHBGVFC', 11);
INSERT INTO Learning.Customer VALUES (19, 'C00019', 'Yearannaidu', 'Chennai', 'Chennai', 'India', 1, 8000, 7000, 7000, 8000, 'ZZZZBFV', 10);
INSERT INTO Learning.Customer VALUES (20, 'C00020', 'Albert', 'New York', 'New York', 'USA', 3, 5000, 7000, 6000, 6000, 'BBBBSBB', 8);

INSERT INTO Learning.Customer VALUES (21, 'C00021', 'Jacks', 'Brisban', 'Brisban', 'Australia', 1, 7000, 7000, 7000, 7000, 'WERTGDF', 11);
INSERT INTO Learning.Customer VALUES (22, 'C00022', 'Avinash', 'Mumbai', 'Mumbai', 'India', 2, 7000, 11000, 9000, 9000, '113-12345678', 2);
INSERT INTO Learning.Customer VALUES (23, 'C00023', 'Karl', 'London', 'London', 'UK', 0, 4000, 6000, 7000, 3000, 'AAAABAA', 6);
INSERT INTO Learning.Customer VALUES (24, 'C00024', 'Cook', 'London', 'London', 'UK', 2, 4000, 9000, 7000, 6000, 'FSDDSDF', 6);
INSERT INTO Learning.Customer VALUES (25, 'C00025', 'Ravindran', 'Bangalore', 'Bangalore', 'India', 2, 5000, 7000, 4000, 8000, 'AVAVAVA', 11);
END;