
--System Database Summary

/*

System databases are defined by Microsoft and are needed for SQL Server to operate.

There are five type of system dtabase

1) master :		Records all the system-level information for an instance of SQL Server.
2) msdb :		It is used by SQL Server Agent for scheduling alerts and jobs.
3) model :		It is used as the template for all databases created on the instance of SQL Server.
4) resourse :	It is a read-only database that contains system objects that are included with SQL Server. 
5) tempdb:		It is a workspace for holding temporary objects or intermediate result sets.

*/


--create Database Traning
IF NOT EXISTS ( SELECT 1 FROM SYS.DATABASE WHERE NAME = 'Traning' )
BEGIN 
	CREATE DATABASE Traning;
END

--Create Schema
IF EXISTS (SELECT 1 FROM SYS.schemas WHERE name = 'Learning')
BEGIN
	DROP SCHEMA [Learning];
END;
GO
	CREATE SCHEMA [Learning];
GO

--Create table
IF OBJECT_ID('Training.Learning.LearnDataType', 'U') IS NOT NULL DROP TABLE Training.Learning.LearnDataType ;
CREATE TABLE Learning.LearnDataTypeds
(
	IDColumn int NOT NULL,
	Column1 char(10),
	Column2 nvarchar(10),
	Column3 bigint NOT NULL,
	Column4 datetime NOT NULL,
	Column5 date,
	Column6 timestamp NOT NULL,
	Column7 nvarchar(MAX)  NOT NULL
)

--Insert Data in table
INSERT INTO Learning.LearnDataType VALUES (01, 'Bhautik', 'M', 123, '2021-06-02 11:40:00', '2021-06-02', DEFAULT,'Angular');
INSERT INTO Learning.LearnDataType VALUES (02, 'Kishan', 'V', 234, '2021-06-02 11:40:15', '2021-06-02', DEFAULT,'dot NET');
INSERT INTO Learning.LearnDataType VALUES (03, 'Suketu', 'M', 345, '2021-06-02 11:40:17', '2021-06-02', DEFAULT,'dot NET');
INSERT INTO Learning.LearnDataType VALUES (04, 'Jay', 'S', 456, '2021-06-02 11:40:20', '2021-06-02', DEFAULT,'dot NET');
INSERT INTO Learning.LearnDataType VALUES (05, 'Jay', 'M', 567, '2021-06-02 11:40:25', '2021-06-02', DEFAULT,'Angular');

SELECT * FROM Learning.LearnDataType;