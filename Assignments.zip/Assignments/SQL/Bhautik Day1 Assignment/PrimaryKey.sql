

BEGIN
IF OBJECT_ID('Training.dbo.PrimaryKeyDemo', 'U') IS NOT NULL DROP TABLE Training.dbo.PrimaryKeyDemo;
CREATE TABLE PrimaryKeyDemo (
	ID int NOT NULL PRIMARY KEY,
    FirstName varchar(255),
    
);
END;


--Success
INSERT INTO PrimaryKeyDemo VALUES (01, 'Bhautik');
INSERT INTO PrimaryKeyDemo VALUES (02, 'Kishan');

--Error
INSERT INTO PrimaryKeyDemo VALUES (02, 'Suketu');



SELECT * FROM PrimaryKeyDemo;