

BEGIN
IF OBJECT_ID('Training.dbo.DefaultDemo', 'U') IS NOT NULL DROP TABLE Training.dbo.DefaultDemo;
CREATE TABLE DefaultDemo (
	ID int NOT NULL,
    FirstName varchar(255) NOT NULL,
    Branch varchar(255) DEFAULT 'CSE'
);
END;


--Success
INSERT INTO DefaultDemo VALUES (01, 'Bhautik', 'CSE');

--Error
INSERT INTO DefaultDemo([ID], [FirstName]) VALUES (02, 'Kishan');



SELECT * FROM DefaultDemo;