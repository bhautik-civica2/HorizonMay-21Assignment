
BEGIN
IF OBJECT_ID('Training.dbo.CheckDemo', 'U') IS NOT NULL DROP TABLE Training.dbo.CheckDemo;
CREATE TABLE CheckDemo (
	ID int NOT NULL,
    FirstName varchar(255) NOT NULL,
    Age int,
    Check (Age>=18)
);
END;


--Success
INSERT INTO CheckDemo VALUES (01, 'Bhautik', 22);

--Error
INSERT INTO CheckDemo VALUES (01, 'Kishan', 15);

SELECT * FROM CheckDemo;