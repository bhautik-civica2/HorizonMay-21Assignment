

BEGIN
IF OBJECT_ID('Training.dbo.PrimaryKeyDemo', 'U') IS NOT NULL DROP TABLE Training.dbo.PrimaryKeyDemo;
CREATE TABLE UniqueDemo (
	ID int NOT NULL UNIQUE,
    FirstName varchar(255) NOT NULL,
    
);
END;

--Success
INSERT INTO UniqueDemo VALUES (01, 'Bhautik');

--Error
INSERT INTO UniqueDemo VALUES (01, 'Kishan');

--Success
INSERT INTO UniqueDemo VALUES (02, 'Suketu');



SELECT * FROM UniqueDemo;