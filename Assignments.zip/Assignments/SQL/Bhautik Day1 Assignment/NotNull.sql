
BEGIN
IF OBJECT_ID('Training.dbo.Notnull', 'U') IS NOT NULL DROP TABLE Training.dbo.Notnull;
CREATE TABLE Notnull (
    ID int,
    LastName varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL
);
END;

--Success
INSERT INTO Notnull VALUES (01, 'Makwana', 'Bhautik');

--Errror
INSERT INTO Notnull([LastName], [FirstName]) VALUES ('Vaja', 'Kishan');



SELECT * FROM Notnull;


DROP TABLE Notnull;