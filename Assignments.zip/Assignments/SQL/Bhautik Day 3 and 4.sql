
use Training;

--Agent table
BEGIN
IF OBJECT_ID('Training.Learning.Agent', 'U') IS NOT NULL DROP TABLE Training.Learning.Agent;
CREATE TABLE Learning.Agent (
    AgentID int NOT NULL PRIMARY KEY,
	Agent_Code char(6) UNIQUE,
	Agent_Name char(40) NOT NULL,
	Working_Area char(35),
	Commission decimal (10,2),
	Phone_No char(15),
	Country varchar(25),

); 
END;

--Customer table
BEGIN
IF OBJECT_ID('Training.Learning.Customer', 'U') IS NOT NULL DROP TABLE Training.Learning.Customer;
CREATE TABLE Learning.Customer (
    CustID int NOT NULL PRIMARY KEY,
	Cust_Code varchar(6) NOT NULL,
	Cust_Name varchar(40),
	Cust_City char(35),
	Working_Area varchar(35),
	Cust_Country varchar(20),
	Grade int,
	Opening_Amt decimal(12,2),
	Receive_Amt decimal(12,2),
	Payment_Amt decimal(12,2),
	Outstanding_Amt decimal(12,2),
	Phone_No varchar(17),
	AgentID int,
	FOREIGN KEY (AgentID) REFERENCES Learning.Agent(AgentID)

);
END;

--Customer Table Data

BEGIN
INSERT INTO Learning.Customer VALUES (01, 'C00001', 'Micheal', 'New York', 'New York', 'USA', 2, 3000, 5000, 2000, 6000, 'CCCCCCC', 8);
INSERT INTO Learning.Customer VALUES (02, 'C00002', 'Bolt', 'New York', 'New York', 'USA', 3, 5000, 7000, 9000, 3000, 'DDNRDRH', 8);
INSERT INTO Learning.Customer VALUES (03, 'C00003', 'Martin', 'Torento', 'Canada', 'USA', 2, 8000, 7000, 7000, 8000, 'MJYURFD', 10);
INSERT INTO Learning.Customer VALUES (04, 'C00004', 'Winston', 'Brisban', 'Brisban', 'Australia', 1, 5000, 8000, 7000, 6000, 'AAAAAAA', 11);
INSERT INTO Learning.Customer VALUES (05, 'C00005', 'Sasikant', 'Mumbai', 'Mumbai', 'India', 1, 7000, 11000, 7000, 11000, 'CCCCCCC', 2);

INSERT INTO Learning.Customer VALUES (06, 'C00006', 'Shilton', 'Torento', 'Torento York', 'Canada', 1, 1000, 7000, 6000, 11000, 'DDDDDDD', 10);
INSERT INTO Learning.Customer VALUES (07, 'C00007', 'Ramanathan', 'Chennai', 'Chennai', 'India', 1, 7000, 11000, 9000, 9000, 'GHRDWSD', 10);
INSERT INTO Learning.Customer VALUES (08, 'C00008', 'Karolina', 'Torento', 'Torento', 'Canada', 1, 7000, 7000, 9000, 5000, 'HJKORED', 10);
INSERT INTO Learning.Customer VALUES (09, 'C00009', 'Ramesh', 'Mumbai', 'Mumbai', 'India', 3, 8000, 7000, 3000, 12000, 'Phone No', 2);
INSERT INTO Learning.Customer VALUES (10, 'C00010', 'Charles', 'Hampshair', 'Hampshair', 'UK', 3, 6000, 4000, 5000, 5000, 'MMMMMMM', 9);

INSERT INTO Learning.Customer VALUES (11, 'C00011', 'Sundariya', 'Chennai', 'Chennai', 'India', 3, 7000, 11000, 7000, 11000, 'PPHGRTS', 10);
INSERT INTO Learning.Customer VALUES (12, 'C00012', 'Steven', 'San Jose', 'San Jose', 'USA', 1, 5000, 7000, 9000, 3000, 'KRFYGJK', 12);
INSERT INTO Learning.Customer VALUES (13, 'C00013', 'Holmes', 'London', 'London', 'UK', 2, 6000, 5000, 7000, 4000, 'BBBBBBB', 3);
INSERT INTO Learning.Customer VALUES (14, 'C00014', 'Rangarappa', 'Bangalore', 'Bangalore', 'India', 2, 8000, 11000, 7000, 12000, 'AAAATGF', 1);
INSERT INTO Learning.Customer VALUES (15, 'C00015', 'Stuart', 'London', 'London', 'UK', 1, 6000, 8000, 3000, 11000, 'GFSGERS', 3);

INSERT INTO Learning.Customer VALUES (16, 'C00016', 'Venkatpati', 'Bangalore', 'Bangalore', 'India', 2, 8000, 11000, 7000, 12000, 'JRTVFDD', 7);
INSERT INTO Learning.Customer VALUES (17, 'C00017', 'Srinivas', 'Bangalore', 'Bangalore', 'India', 2, 8000, 4000, 3000, 9000, 'AAAAAAB', 7);
INSERT INTO Learning.Customer VALUES (18, 'C00018', 'Fleming', 'Brisban', 'Brisban', 'Australia', 2, 7000, 7000, 9000, 5000, 'NHBGVFC', 11);
INSERT INTO Learning.Customer VALUES (19, 'C00019', 'Yearannaidu', 'Chennai', 'Chennai', 'India', 1, 8000, 7000, 7000, 8000, 'ZZZZBFV', 10);
INSERT INTO Learning.Customer VALUES (20, 'C00020', 'Albert', 'New York', 'New York', 'USA', 3, 5000, 7000, 6000, 6000, 'BBBBSBB', 8);

INSERT INTO Learning.Customer VALUES (21, 'C00021', 'Jacks', 'Brisban', 'Brisban', 'Australia', 1, 7000, 7000, 7000, 7000, 'WERTGDF', 11);
INSERT INTO Learning.Customer VALUES (22, 'C00022', 'Avinash', 'Mumbai', 'Mumbai', 'India', 2, 7000, 11000, 9000, 9000, '113-12345678', 2);
INSERT INTO Learning.Customer VALUES (23, 'C00023', 'Karl', 'London', 'London', 'UK', 0, 4000, 6000, 7000, 3000, 'AAAABAA', 6);
INSERT INTO Learning.Customer VALUES (24, 'C00024', 'Cook', 'London', 'London', 'UK', 2, 4000, 9000, 7000, 6000, 'FSDDSDF', 6);
INSERT INTO Learning.Customer VALUES (25, 'C00025', 'Ravindran', 'Bangalore', 'Bangalore', 'India', 2, 5000, 7000, 4000, 8000, 'AVAVAVA', 11);
END;

/* Question - 1*/
create or alter view Learning.CCN
as
select Cust_City,  
Customer_Names = stuff  
(  
    (  
      select distinct ', '+ cast(Cust.Cust_Name as varchar(max))  
      from Learning.Agent Agnt, Learning.Customer Cust
      where Cust.Cust_City = Cust1.Cust_City
      for xml path('')  
    ),1,1,''  
)  
from Learning.Customer Cust1
group by Cust_City  
GO

select * from Learning.CCN
GO

--Q.2
create view V1 as
BEGIN
	select A.Agent_Name, C.Cust_Name, C.Cust_City, C.Cust_Country, C.Outstanding_Amt, A.Commission
	from Learning.Customer C
	join Learning.Agent A on A.AgentID = C.AgentID;
END

select Agent_Name, Cust_Name, Cust_City, Cust_Country, Outstanding_Amt, Commission  from V1

/* Question - 2 */


--Q.1
CREATE OR ALTER PROCEDURE Learning.FirstQuestion
(
	@AgentID int,
	@Agent_Code char(6),
	@Agent_Name char(40),
	@Working_Area char(35),
	@Commission decimal (10,2),
	@Phone_No char(15),
	@Country varchar(25)
)
AS
BEGIN
	set nocount on
	insert into Learning.Agent values
	(
		@AgentID,
		convert(char(6), @Agent_Code),
		convert(char(40), @Agent_Name),
		convert(char(35), @Working_Area),
		convert(decimal (10,2), @Commission),
		convert(char(15), @Phone_No),
		CONVERT(varchar(25), @Country)
	)

	select * from Learning.Agent where AgentID = @AgentID;
END
GO

EXEC Learning.FirstQuestion
@AgentID = 13,
@Agent_Code = 'A013',
@Agent_Name = 'Bhautik',
@Working_Area = 'India',
@Commission = '0.10',
@Phone_No = '091-8690872121',
@Country = ''
GO

--Q.2
CREATE OR ALTER PROCEDURE Learning.SecondQuestion
(
	@CustID int,
	@Cust_Code varchar(6),
	@Cust_Name varchar(40),
	@Cust_City char(35),
	@Working_Area varchar(35),
	@Cust_Country varchar(20),
	@Grade int,
	@Opening_Amt decimal(12,2),
	@Receive_Amt decimal(12,2),
	@Payment_Amt decimal(12,2),
	@Outstanding_Amt decimal(12,2),
	@Phone_No varchar(17),
	@AgentID int
)
AS
BEGIN
	set nocount on
	insert into Learning.Customer values
	(
		@CustID,
		@Cust_Code,
		@Cust_Name,
		@Cust_City,
		@Working_Area,
		@Cust_Country,
		@Grade,
		@Opening_Amt,
		@Receive_Amt,
		@Payment_Amt,
		@Outstanding_Amt,
		@Phone_No,
		@AgentID
	)

	select CustID, Cust_Code, Cust_Name, Cust_City, Working_Area, Cust_Country, Opening_Amt, Receive_Amt, Outstanding_Amt, Phone_No, AgentID
	from Learning.Customer
	where CustID = @CustID;
END
GO

EXEC Learning.SecondQuestion
@CustID = 26,
@Cust_Code = 'C00026',
@Cust_Name = 'Witcher',
@Cust_City = 'Botad',
@Working_Area = 'Botad',
@Cust_Country = 'India',
@Grade = 1,
@Opening_Amt = 2000,
@Receive_Amt = 3000,
@Payment_Amt = 4000,
@Outstanding_Amt = 5000,
@Phone_No = '8690872121',
@AgentID = 5
GO

--Q.3
CREATE OR ALTER PROCEDURE Learning.ThirdQuestion @AgentID int, @Updatedagentname char(40)
AS
BEGIN
	update Learning.Agent
	set Agent_Name = @Updatedagentname
	where AgentID = @AgentID

	select A.AgentID, A.Agent_Code, A.Agent_Name, A.Working_Area, A.Commission, A.Phone_No, A.Country
	from Learning.Agent A
	where AgentID = @AgentID;
END

EXEC Learning.ThirdQuestion 13, 'bh4utik';

--Q.4
CREATE OR ALTER PROCEDURE Learning.FifthQuestion @CustID int
AS
BEGIN

	delete
	from Learning.Customer
	where CustID = @CustID;

	select CustID, Cust_Code, Cust_Name, Cust_City, Working_Area, Cust_Country, Opening_Amt, Receive_Amt, Outstanding_Amt, Phone_No, AgentID
	from Learning.Customer C;
END

EXEC Learning.FourthQuestion 26;


--Q.5
CREATE OR ALTER PROCEDURE Learning.FifthQuestion
(
	@AgentID int,
	@Agent_Code char(6),
	@Agent_Name char(40),
	@Working_Area char(35),
	@Commission decimal (10,2),
	@Phone_No char(15),
	@Country varchar(25),
	@Updatedagentname char(40)
)
AS
BEGIN
	set nocount on
	insert into Learning.Agent values
	(
		@AgentID,
		convert(char(6), @Agent_Code),
		convert(char(40), @Agent_Name),
		convert(char(35), @Working_Area),
		convert(decimal (10,2), @Commission),
		convert(char(15), @Phone_No),
		CONVERT(varchar(25), @Country)
	)

	update Learning.Agent
	set Agent_Name = @Updatedagentname
	where AgentID = @AgentID

	delete from Learning.Agent where AgentID = @AgentID;

	select A.AgentID, A.Agent_Code, A.Agent_Name, A.Working_Area, A.Commission, A.Phone_No, A.Country
	from Learning.Agent A;
END
GO

EXEC Learning.FifthQuestion
@AgentID = 14,
@Agent_Code = 'A014',
@Agent_Name = 'Avani',
@Working_Area = 'India',
@Commission = '0.30',
@Phone_No = '091-0123456789',
@Country = '',
@Updatedagentname = 'avvnii'
GO

--Q.6
CREATE OR ALTER PROCEDURE Learning.SixthQuestion
(
	@CustID int,
	@Cust_Code varchar(6),
	@Cust_Name varchar(40),
	@Cust_City char(35),
	@Working_Area varchar(35),
	@Cust_Country varchar(20),
	@Grade int,
	@Opening_Amt decimal(12,2),
	@Receive_Amt decimal(12,2),
	@Payment_Amt decimal(12,2),
	@Outstanding_Amt decimal(12,2),
	@Phone_No varchar(17),
	@AgentID int,
	@updatedcustomername char(40)
)
AS
BEGIN
	set nocount on
	insert into Learning.Customer values
	(
		@CustID,
		@Cust_Code,
		@Cust_Name,
		@Cust_City,
		@Working_Area,
		@Cust_Country,
		@Grade,
		@Opening_Amt,
		@Receive_Amt,
		@Payment_Amt,
		@Outstanding_Amt,
		@Phone_No,
		@AgentID
	)

	update Learning.Customer
	set Cust_Name = @updatedcustomername
	where CustID = @CustID

	delete from Learning.Customer where CustID = @CustID;

	select CustID, Cust_Code, Cust_Name, Cust_City, Working_Area, Cust_Country, Opening_Amt, Receive_Amt, Outstanding_Amt, Phone_No, AgentID
	from Learning.Customer C;
END
GO

EXEC Learning.SixthQuestion
@CustID = 27,
@Cust_Code = 'C00027',
@Cust_Name = 'WitcherYT',
@Cust_City = 'Erangle',
@Working_Area = 'Erangle',
@Cust_Country = 'PUBG',
@Grade = 1,
@Opening_Amt = 2000,
@Receive_Amt = 3000,
@Payment_Amt = 4000,
@Outstanding_Amt = 5000,
@Phone_No = '8690872121',
@AgentID = 5,
@updatedcustomername = 'WitcherOP'
GO

--Q.7
create or alter procedure Learning.SeventhQuestion
	@AgentID int,
	@Agent_Name char(40),
	@CustID INT,
	@Cust_Name varchar(40),
	@UserInput varchar(25)
as
begin
	if @UserInput = 'Agent Name'
	begin
	select *
	from Learning.Agent
	where Agent_Name = @Agent_Name
	end

	if @UserInput = 'AgentID'
	begin
	select *
	from Learning.Agent
	where AgentID = @AgentID
	end

	if @UserInput = 'Customer ID'
	begin
	select *
	from Learning.Customer
	where CustID = @CustID
	end

	if @UserInput = 'Customer Name'
	begin
	select *
	from Learning.Customer
	where Cust_Name = @Cust_Name
	end
end
go

exec Learning.SeventhQuestion
@AgentID = 13,
@Agent_Name = 'ivan',
@CustID = 16,
@Cust_Name = 'bolt',
@UserInput = 'Customer Name'

/* Question 3 */
create function Learning.Cal
(
	--@CustID int
	@AgentID int
)
returns decimal(10, 2)
as
begin
	declare @comm decimal(10, 2)

	/*
	select @comm = A.Commission
	from Learning.Customer C 
	join Learning.Agent A on A.AgentID = C.AgentID
	where C.CustID = @CustID;
	*/

	select @comm =  A.Commission
	from Learning.Agent A
	where A.AgentID = @AgentID;

	return @comm;
end
go

select C.CustID, C.Cust_Name, A.Agent_Name, C.Outstanding_Amt, A.Commission, C.Outstanding_Amt *  Learning.Cal(A.AgentID) as Total_Commision
from Learning.Customer C
join Learning.Agent A on A.AgentID = C.AgentID;

/* Question 4 */
create or alter function Learning.TVF()
returns table
as
return
(
	select * from Learning.Agent
)

select AgentID, Agent_Code, Working_Area, Commission, Phone_No, Country
from Learning.TVF();

select CustID, Cust_Name, Outstanding_Amt, Agent_Name,Agent_Code, Commission
from Learning.TVF()
join Learning.Customer C on C.AgentID = TVF.AgentID;




/* Question 5 */
create nonclustered index NC_Customer on learning.Customer(Cust_Code)

select Cust_Code, Cust_Name, Opening_Amt, Outstanding_Amt
from learning.Customer
where Cust_Code = 'C00007'; 

/* Question 6 */
create nonclustered index NC_Agent on learning.Agent (Agent_Code)

select Agent_Code,Agent_Name,Commission
from learning.Agent
where Agent_Code = 'A007'

/* Question 7 */
BEGIN
IF OBJECT_ID('Training.Learning.AuditAgentTable', 'U') IS NOT NULL DROP TABLE Training.Learning.AuditAgentTable;
CREATE TABLE Learning.AuditAgentTable
(
    AgentID INT,
    Agent_Code CHAR(6),
    Agent_Name CHAR(40),
    Working_Area CHAR(35),
    Commission DECIMAL(10,2),
    Phone_No CHAR(15),
    Country VARCHAR(25),
    TransactionDate DATE,
    TransactionType VARCHAR(25)
)
END
GO

SELECT AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No, Country
FROM Learning.Agent;

SELECT AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No, Country, TransactionDate, TransactionType
FROM Learning.AuditAgentTable;
GO

CREATE TRIGGER AgentTrigger
ON Learning.Agent
FOR INSERT, UPDATE, DELETE
AS        
    DECLARE
    @AgentID INT,
    @Agent_Code CHAR(6),
    @Agent_Name CHAR(40),
    @Working_Area CHAR(35),
    @Commission DECIMAL(10,2),
    @Phone_No CHAR(15),
    @Country VARCHAR(25),
    @Audit_Action VARCHAR(25);
    
    DECLARE
	@DELAgentID INT,
    @DELAgent_Code CHAR(6),
    @DELAgent_Name CHAR(40),
    @DELWorking_Area CHAR(35),
    @DELCommission DECIMAL(10,2),
    @DELPhone_No CHAR(15),
    @DELCountry VARCHAR(25),
    @DELAudit_Action VARCHAR(100),
    @Audit_Action_Delete VARCHAR(25);

    SELECT @AgentID = i.AgentID
    FROM inserted i
    SELECT  @Agent_Code = i.Agent_Code
    FROM inserted i;
    SELECT  @Agent_Name = i.Agent_Name
    FROM inserted i;
    SELECT  @Working_Area = i.Working_Area
    FROM inserted i;
    SELECT  @Commission = i.Commission  
    FROM inserted i;
    SELECT  @Phone_No = i.Phone_No  
    FROM inserted i;
    SELECT  @Country = i.Country
    FROM inserted i;
    SET @Audit_Action = 'Inserted Records After Insert Trigger';
   
        
    SELECT  @DELAgentID = d.AgentID  
    FROM deleted d;
    SELECT  @DELAgent_Code = d.Agent_Code
    FROM deleted d;
    SELECT  @DELAgent_Name = d.Agent_Name
    FROM deleted d;
    SELECT  @DELWorking_Area = d.Working_Area
    FROM deleted d;
    SELECT  @DELCommission = d.Commission  
    FROM deleted d;
    SELECT  @DELPhone_No = d.Phone_No  
    FROM deleted d;
    SELECT  @DELCountry = d.Country
    FROM deleted d;
    
    IF UPDATE(Agent_Name)
        SET @Audit_Action = 'Updated Recored -- After Updating trigger';
    IF UPDATE(Agent_Code)
        SET @Audit_Action = 'Updated Recored -- After Updating trigger';
    IF UPDATE(Working_Area)
        SET @Audit_Action = 'Updated Recored -- After Updating trigger';
    IF UPDATE(Commission)
        SET @Audit_Action = 'Updated Recored -- After Updating trigger';
    IF UPDATE(Phone_No)
        SET @Audit_Action = 'Updated Recored -- After Updating trigger';
    IF UPDATE(Country)
        SET @Audit_Action = 'Updated Recored -- After Updating trigger';
 
	INSERT INTO Learning.AuditAgentTable
	(
		Agent_Code,
		Agent_Name, 
		Working_Area,
		Commission,
		Phone_No,
		Country,
		TransactionDate,
		TransactionType
	)
	VALUES (@Agent_Code, @Agent_Name, @Working_Area, @Commission, @Phone_No, @Country, getdate(), @Audit_Action);
	PRINT 'AFTER INSERT TRIGGER FIRED.'     

    INSERT INTO Learning.AuditAgentTable
    (
		Agent_Code,
		Agent_Name, 
		Working_Area,
		Commission,
		Phone_No,
		Country,
		TransactionDate,
		TransactionType
	)
    VALUES (@DELAgent_Code, @DELAgent_Name, @DELWorking_Area, @DELCommission, @DELPhone_No, @DELCountry, getdate(), @Audit_Action);
    PRINT 'AFTER DELETE TRIGGER FIRED.'     
GO

INSERT INTO Learning.Agent
(AgentID, Agent_Code, Agent_Name, Working_Area, Commission, Phone_No, Country) 
VALUES (15, 'A015','witch3r','Erangle', 0.11, '8690872121', NULL);
GO
 
SELECT A.AgentID, A.Agent_Code, A.Agent_Name, A.Working_Area, A.Commission, A.Phone_No, A.Country
FROM Learning.Agent A;

SELECT AA.AgentID, AA.Agent_Code, AA.Agent_Name, AA.Working_Area, AA.Commission, AA.Phone_No, AA.Country,  AA.TransactionDate, AA.TransactionType
FROM Learning.AuditAgentTable AA;
 
UPDATE Learning.Agent 
SET Working_Area = 'Baroda'
WHERE Agent_Name = 'witch3r'



--Display table
SELECT * FROM Learning.Customer;
SELECT * FROM Learning.Agent; 

--aggregate

select SUM(Grade) as Average_Opening_Amount from Learning.Customer;			-- sum all grade from customer table

select AVG(Opening_Amt) as Grades from Learning.Customer;					-- calculate average of opening ammount from customer table

select MIN(Payment_Amt) as Maximum_Received_Amount from Learning.Customer;	-- find lowest payment ammount from customer table

select MAX(Receive_Amt) as Minimum_Payment_Amount  from Learning.Customer;	-- find highest payment ammount from customer table

select CHECKSUM(Grade) from Learning.Customer order by Grade;

select COUNT(AgentID) from Learning.Agent;									-- count total no og agentId from agent table


--date function
select 
	getdate(),
	convert(date, sysdatetime()),		-- has more precision then gettime()
	convert(date, sysdatetimeoffset()),	-- date and time of the computer on which the instance of SQL Server is running and the time zone offset is included.
	convert(date, sysutcdatetime()),	--same as sysdatetimeoffset()
	convert(date, getdate()),			--represent current system date and time
	convert(date, getutcdate());		-- current database system timestamp as a datetime value
GO

--time function
select 
	convert(time, sysdatetime()),		-- has more precision then gettime()
	convert(time, sysdatetimeoffset()),	-- date and time of the computer on which the instance of SQL Server is running and the time zone offset is included.
	convert(time, sysutcdatetime()),	--same as sysdatetimeoffset()
	convert(time, current_timestamp),	-- returns the current database system timestamp as a datetime value, without the database time zone offset
	convert(time, getdate()),			-- represent current system date and time
	convert(time, getutcdate())			-- current database system timestamp as a datetime value
GO

--Other Functions

--isnull()
SELECT (ISNULL(Country, 'country_name'))		-- replaces NULL with the specified replacement value
FROM Learning.Agent;  
GO

--isnumeric()
SELECT Cust_Code, Cust_Name						--	this will return all Cust_Code that is not numeric type
FROM Learning.Customer   
WHERE ISNUMERIC(Cust_Code) <> 1;  
GO 

--newid()
DECLARE @_ID uniqueidentifier					-- creates a unique value of type uniqueidentifier.
SET @_ID = NEWID()  
PRINT 'Value of @_ID is: '+ CONVERT(varchar(255), @_ID)

--session contex
EXEC sp_set_session_context 'user_id', 111;		-- returns the value of the specified key in the current session context. The value is set by using the sp_set_session_context (Transact-SQL) procedure.
SELECT SESSION_CONTEXT(N'user_id'); 

--Identity
insert into Learning.Agent values (16, 'A016', 'Deadshot', 'Erangle', 0.15, '0123456789', '');
SELECT @@IDENTITY AS 'Identity'					-- return the AgentID of last instered row
select Max(AgentID) from Learning.Agent

select * from Learning.Agent

--RowCount
UPDATE Learning.Agent   
SET Working_Area = 'Vikendi'  
WHERE AgentID = 16
IF @@ROWCOUNT = 0								-- returns the number of rows affected by the last statement.
PRINT 'Warning: No rows were updated';  
GO

select * from Learning.Agent
