import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IUsers } from './users.model';
import { tap } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class MainService {

  readonly _userUrl:string = 'https://jsonplaceholder.typicode.com/users'

  constructor(private http:HttpClient) { }

  //fetching data from userUrl
  fetchUser(): Observable<IUsers[]> {
    return this.http.get<IUsers[]>(this._userUrl).pipe(
      tap(data => console.log('Users responce...', JSON.stringify(data)))   //responce from the services
    )
  }
}
