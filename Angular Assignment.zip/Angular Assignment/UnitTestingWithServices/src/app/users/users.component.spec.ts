import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UsersComponent } from './users.component';
import { HttpClientTestingModule } from '@angular/common/http/testing'
import { MainService } from './main.service';
import { MockMainService } from './mockmain.service';
import { By } from '@angular/platform-browser';

fdescribe('UsersComponent', () => {
  let component: UsersComponent;
  let fixture: ComponentFixture<UsersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ 
        UsersComponent
      ],
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        {
          provide: MainService,
          useClass: MockMainService
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check 10 users', () => {
    component.getData();
    expect(component.users.length).toEqual(10)  //toEqual() is use for array purpose & toBe() is used for string or number purpose
  })

  it('should check user are loaded', () => {
    component.getData();
    const queryUser = fixture.debugElement.queryAll(By.css('.user'))

    expect(queryUser.length).toEqual(10)
  })

  it(`should check first user name is 'Leanne Graham' method 1 `, () => {
    component.getData();
    expect(component.users[0].name).toEqual('Leanne Graham')
  })

  // it(`should check first user name is 'Leanne Graham' method 2 `, () => {
  //   component.getData();
  //   const queryUser = fixture.debugElement.queryAll(By.css('.user'))
  //   const userName = queryUser[0].nativeElement.querySelector('td')

  //   expect(userName.innerText).toContain('Leanne Graham')
  // })
});
