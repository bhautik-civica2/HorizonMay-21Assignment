import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IUsers } from './users.model';
import { tap } from 'rxjs/operators'
import { MockData } from './mockdata';

@Injectable({
  providedIn: 'root'
})
export class MockMainService {

  readonly _userUrl:string = 'https://jsonplaceholder.typicode.com/users'

  constructor(private http:HttpClient) { }

  //fetching mockdata from MockData
  fetchUser(): Observable<IUsers[]> {
    const mockusers = MockData.MockUsers
    return new Observable<IUsers[]>(responce => {
        responce.next(mockusers)
    })
  }
}
