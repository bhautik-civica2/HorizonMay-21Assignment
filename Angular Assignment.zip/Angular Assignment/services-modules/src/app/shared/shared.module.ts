import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedOneComponent } from './shared-one/shared-one.component';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    SharedOneComponent
  ],
  exports: [
    SharedOneComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule
  ]
})
export class SharedModule { }
