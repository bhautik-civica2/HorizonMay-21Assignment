import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from 'src/app/main.service';

@Component({
  selector: 'app-shared-one',
  templateUrl: './shared-one.component.html',
  styleUrls: ['./shared-one.component.css']
})
export class SharedOneComponent implements OnInit {

  title:string = 'Shared Component'
  data:any = []

  constructor(private _main:MainService, private router: Router) { }

  getdata() {
    this._main.fetchAlbum()
    .subscribe(d => this.data = d)
  }

  ngOnInit(): void {
    this.getdata()
  }

  onBack(): void {
    this.router.navigate(['/feature']);
  }

}
