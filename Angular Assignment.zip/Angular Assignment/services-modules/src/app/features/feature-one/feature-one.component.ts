import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from 'src/app/main.service';

@Component({
  selector: 'app-feature-one',
  templateUrl: './feature-one.component.html',
  styleUrls: ['./feature-one.component.css']
})
export class FeatureOneComponent implements OnInit {
  title:string = 'Feature Component'
  data:any = []

  constructor(private _main:MainService, private router: Router) { }

  getdata() {
    this._main.fetchData()
    .subscribe(d => this.data = d)
  }

  ngOnInit(): void {
    // this.getCat()
    this.getdata()
  }

  onBack(): void {
    this.router.navigate(['/home']);
  }
}
