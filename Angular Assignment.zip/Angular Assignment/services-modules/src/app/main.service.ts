import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainService {

  // readonly catUrl:string = 'https://api.thecatapi.com/v1/images/search'

  // readonly catUrl:string = 'https://elephant-api.herokuapp.com/elephants/random'

  readonly dataUrl:string = 'https://jsonplaceholder.typicode.com/users'

  readonly albumUrl:string = 'https://jsonplaceholder.typicode.com/albums'
  
  constructor(private http:HttpClient) { }

  fetchData(): Observable<any[]> {
    return this.http.get<any[]>(this.dataUrl)
  }

  fetchAlbum(): Observable<any[]> {
    return this.http.get<any[]>(this.albumUrl)
  }
}
