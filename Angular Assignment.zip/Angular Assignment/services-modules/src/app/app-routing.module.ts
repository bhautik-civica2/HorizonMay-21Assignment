import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { FeatureOneComponent } from './features/feature-one/feature-one.component';
import { HomeComponent } from './home/home.component';
import { SharedOneComponent } from './shared/shared-one/shared-one.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'feature', component: FeatureOneComponent },
  { path: 'shared', component: SharedOneComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
