import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IUsers } from './users/users.model';
import { map, tap } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class MainService {

  readonly _url:string = 'https://jsonplaceholder.typicode.com/users'
  // private _url:string = 'https://reqres.in/api/users?page=1'
  

  constructor(private http:HttpClient) { }

  //fetching data from userUrl
  fetchUser(): Observable<any> {
    return this.http.get<any>(this._url)
  }

  fetchCurrentUser(id: number) {
    return this.http.get(`${this._url}/${id}`)
  }

  updateFetchedUser(id: number, data:any) {
    return this.http.get(`${this._url}/${id}`, data)
  }
}
