import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent{

  title:string = 'Create User'

  // readonly _url:string = 'https://jsonplaceholder.typicode.com/users'

  constructor(private fb: FormBuilder, private http: HttpClient) { }

  profileForm = this.fb.group({
    id: ['', [Validators.required]],
    name: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(30)]],
    username: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(250)]],
  });


  createUser() {
    this.http.post('https://localhost:44362/api/Trainer/createtrainer', this.profileForm.value)
    .subscribe(data => {
      console.log('user created successfully...', data)
    })
  }
}
