import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MainService } from '../main.service';
import { IUsers } from './users.model';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  title:string = 'User Component'
  //define user data array
  users:IUsers[]

  constructor(private _mainService:MainService,
              private router:Router) {
    this.users = new Array<IUsers>()  //decalre user data array
   }

  //method for retriving user data from services
  getData() {
    this._mainService.fetchUser()
    .subscribe(responce => {
      this.users = responce
      console.log('Users data...', this.users)  //responce from component
    })
  }


  deleteUser() {

  }

  ngOnInit(): void {
    this.getData()
  }

}
