import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MainService } from '../main.service';
import { IUsers } from '../users/users.model';

@Component({
  selector: 'app-put',
  templateUrl: './put.component.html',
  styleUrls: ['./put.component.css']
})
export class PutComponent implements OnInit{

  title:string = 'Update User'
  // user:any = {}

  constructor(private fb: FormBuilder, private http: HttpClient, private router: ActivatedRoute, private _main: MainService) { }

  profileForm = this.fb.group({
    id: ['', [Validators.required]],
    name: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(30)]],
    username: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(250)]],
  });


  public updateProfile() {
    this.profileForm.patchValue({
      id: '11',
      name: 'Bhautik',
      username: 'bh4utik',
      email: 'mba@gmail.com'
    });
  }

  ngOnInit():void {
    this._main.fetchCurrentUser(this.router.snapshot.params.id)
    .subscribe( responce => {
      console.log(responce)
      })
  }

  updateUser() {
    this._main.updateFetchedUser(this.router.snapshot.params.id, this.profileForm.value)
    .subscribe(res => {
      console.log('update user successfully...', res)
    })
  }

}
