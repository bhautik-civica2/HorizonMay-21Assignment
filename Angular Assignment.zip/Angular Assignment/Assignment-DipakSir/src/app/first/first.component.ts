import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent{
  info : string = 'Info'
  person : any[] = [
    {
      "name" : "bhautik",
      "field" : 'angular',
      "age" : 22
    },
    {
      "name" : 'kishan',
      "field" : 'mvc',
      "age" : 23
    },
    {
      "name" : 'jay',
      "field" : 'angular',
      "age" : 22
    },
    {
      "name" : 'pooja',
      "field" : 'angular',
      "age" : 23
    },
  ]
}
