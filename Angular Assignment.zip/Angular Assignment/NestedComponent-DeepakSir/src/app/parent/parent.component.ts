import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  title: string = 'Parent Component'
  

  parentToChild: string = 'parent'

  childData:string = ''
  
  parentMethod(data:any) {
    this.childData = data.name
  }

  // parentButton() {
    
  // }

  // username:string = ''
  // onUserClick(data:any) {
  //   this.username = data
  // }

  constructor() { }

  ngOnInit(): void {
  }

}
