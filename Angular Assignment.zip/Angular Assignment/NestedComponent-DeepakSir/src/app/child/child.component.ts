import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  title: string = 'Child Component'

  @Input() ptc:string = ''
  
  @Output()
  notify:EventEmitter<any> = new EventEmitter<any>()

  passData() {
    let item = {
      name : 'bhautik'
    }
    this.notify.emit(item)
  }

  // @Output()
  // userclick:EventEmitter<any> = new EventEmitter<any>()

  // users: any = [
  //   {
  //     "id": "1",
  //     "name": 'bhautik'
  //   },
  //   {
  //     "id": "2",
  //     "name": 'jay'
  //   },
  //   {
  //     "id": "3",
  //     "name": 'pooja'
  //   }
  // ]

  // passUsername() {
  //   this.userclick.emit(this.users.name)
  //   console.log(this.users.name)
  //   // this.userclick.emit(` clicked`)
  // }

  constructor() { }

  

  ngOnInit(): void {
    
  }
}
