import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { BehaviorsubjectComponent } from './behaviorsubject/behaviorsubject.component';
import { HomeComponent } from './home/home.component';
import { OperatorsComponent } from './operators/operators.component';
import { ReplaysubjectComponent } from './replaysubject/replaysubject.component';
import { SubjectsComponent } from './subjects/subjects.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  {path: 'subject', component:SubjectsComponent},
  {path: 'behavior', component:BehaviorsubjectComponent},
  {path: 'replay', component:ReplaysubjectComponent},
  {path: 'operators', component:OperatorsComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
