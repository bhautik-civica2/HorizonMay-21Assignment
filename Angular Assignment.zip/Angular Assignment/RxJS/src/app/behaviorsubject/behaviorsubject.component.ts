import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Component({
  selector: 'app-behaviorsubject',
  templateUrl: './behaviorsubject.component.html',
  styleUrls: ['./behaviorsubject.component.css']
})
export class BehaviorsubjectComponent implements OnInit {

  subject2$ = new BehaviorSubject<number>(0);

  constructor() { }

  ngOnInit(): void {
    this.subject2$.subscribe({
      next: (v) => {
        console.log(`Observable A - ${v}`)
      }
    })

    this.subject2$.next(1)
    this.subject2$.next(2)

    // debugger
    this.subject2$.subscribe({
      next: (v) => {
        console.log(`Observer B - ${v}`)
      }
    })

    this.subject2$.next(3)
  }

  btnOne() {
    this.subject2$.next(4)
  }

}
