import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Subject } from 'rxjs/internal/Subject';


@Component({
  selector: 'app-subjects',
  templateUrl: './subjects.component.html',
  styleUrls: ['./subjects.component.css']
})
export class SubjectsComponent implements OnInit {
  
  subject1$ = new Subject<number>();
  subject2$ = new BehaviorSubject<number>(0);

  constructor() { }

  ngOnInit(): void {
    this.subject1$.subscribe({
      next: (v) => {
        console.log(`Observable A - ${v}`)
      }
    })

    this.subject1$.next(1)

    this.subject1$.subscribe({
      next: (v) => {
        console.log(`Observaber B - ${v}`)
      }
    })
  }

  btnOne() {
    this.subject1$.next(2)
  }

}
