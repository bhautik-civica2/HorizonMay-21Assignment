import { Component, OnInit } from '@angular/core';
import { ReplaySubject } from 'rxjs';

@Component({
  selector: 'app-replaysubject',
  templateUrl: './replaysubject.component.html',
  styleUrls: ['./replaysubject.component.css']
})
export class ReplaysubjectComponent implements OnInit {

  subject2$ = new ReplaySubject<number>(3);

  constructor() { }

  ngOnInit(): void {
    this.subject2$.subscribe({
      next: (v) => {
        console.log(`Observable A - ${v}`)
      }
    })

    this.subject2$.next(1)
    this.subject2$.next(2)
    this.subject2$.next(3)
    this.subject2$.next(4)

    // debugger
    this.subject2$.subscribe({
      next: (v) => {
        console.log(`Observer B - ${v}`)
      }
    })

    this.subject2$.next(5)
  }

  btnOne() {
    this.subject2$.next(6)
  }

}
