import { Component, OnInit } from '@angular/core';
import { fromEvent, interval, Observable, of, timer } from 'rxjs';
import { map, startWith, endWith, takeUntil, mergeMap, concatMap, take } from 'rxjs/operators';

@Component({
  selector: 'app-operators',
  templateUrl: './operators.component.html',
  styleUrls: ['./operators.component.css']
})
export class OperatorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    

  }

  startWithOperator() {
    timer(1000)
    .pipe(
      map(() => 'timer emit'),
      startWith('timer start')
    )
    .subscribe(x => console.log(x));
  }

  endWithOperator() {
    const ticker$ = interval(5000).pipe(
      map(() => 'tick'),
    );
     
    const documentClicks$ = fromEvent(document, 'click');
     
    ticker$.pipe(
      startWith('interval started'),
      takeUntil(documentClicks$),
      endWith('interval ended by click')
    )
    .subscribe(x => console.log(x));
  }

  mergeMapOperator() {
    const letters = of('a', 'b', 'c');
    const result = letters.pipe(
      mergeMap(x => interval(1000).pipe(map(i => x+i))),
    );
    result.subscribe(x => console.log(x));
  }

  concatMapOperator() {
    const clicks = fromEvent(document, 'click');
    const result = clicks.pipe(
      concatMap(ev => interval(1000).pipe(take(4)))
    );
    result.subscribe(x => console.log(x));
  }


}

