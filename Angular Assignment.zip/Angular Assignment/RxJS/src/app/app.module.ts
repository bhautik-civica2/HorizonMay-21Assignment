import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SubjectsComponent } from './subjects/subjects.component';
import { BehaviorsubjectComponent } from './behaviorsubject/behaviorsubject.component';
import { ReplaysubjectComponent } from './replaysubject/replaysubject.component';
import { OperatorsComponent } from './operators/operators.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    SubjectsComponent,
    BehaviorsubjectComponent,
    ReplaysubjectComponent,
    OperatorsComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
