import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AnimalService } from '../animal.service';

@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {

  cat:any = []
  
  constructor(private _servise: AnimalService, private router: Router) { }

  ngOnInit(): void {
    this.getCat()
  }

  getCat() {
    this._servise.fetchCat()
    .subscribe(c => this.cat = c)
  }

  onBack(): void {
    this.router.navigate(['/animal']);
  }

}
