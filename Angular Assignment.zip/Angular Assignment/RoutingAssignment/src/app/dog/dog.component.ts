import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AnimalService } from '../animal.service';

@Component({
  selector: 'app-dog',
  templateUrl: './dog.component.html',
  styleUrls: ['./dog.component.css']
})
export class DogComponent implements OnInit {

  dog:any = []
  constructor(private _servise: AnimalService, private router: Router,) { }

  ngOnInit(): void {
    this.getDog()
  }

  getDog() {
    this._servise.fetchDog()
    .subscribe(d => this.dog = d)
  }

  onBack(): void {
    this.router.navigate(['/animal']);
  }

}
