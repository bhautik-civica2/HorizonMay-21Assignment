import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-profile-editor',
  templateUrl: './profile-editor.component.html', 
  styleUrls: ['./profile-editor.component.css']
})
export class ProfileEditorComponent implements OnInit{
  
  profileForm: any

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.profileForm = this.fb.group({
      firstName: ['witcher', [Validators.required, Validators.maxLength(25), Validators.minLength(3)]],
      lastName: ['', [Validators.required, Validators.maxLength(25)], Validators.minLength(3)],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      address: this.fb.group({
        Address1: [''],
        Address2: [''],
        city: [''],
        state: [''],
        zip: ['364710', [Validators.required, Validators.pattern(/^[1-9][0-9]{5}$/)]]
      }),
    });

    console.log(this.profileForm.controls.firstName.value);
    // console.log(this.fname())
  }

  get fname(): any {
    return this.profileForm.get('firstName');
  }  

  updateProfile() {
    this.profileForm.patchValue({
      firstName: 'bhautik',
      lastName: 'makwana',
      email: 'mba@gmail.com',
      phoneNumber: '8690872121',
      address: {
       zip:'364710'
      }
    });
  }
  

  onSubmit() {
    if (this.profileForm.valid) {
      console.log(this.profileForm.value);
    } else {
      console.log('fukking error')
    }
  }
}