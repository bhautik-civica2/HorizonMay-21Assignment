import {  ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing"
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { ProfileEditorComponent } from "./profile-editor.component";

describe('first component test', () => {
  let component: ProfileEditorComponent;
  let fixture: ComponentFixture<ProfileEditorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        ProfileEditorComponent
      ],
      imports: [
        BrowserModule,
        ReactiveFormsModule,
        FormsModule
      ],
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(ProfileEditorComponent);
      component = fixture.componentInstance;
    })
  }));

  it('test 1'), waitForAsync(() => {
    expect(component).toBeTruthy();
  })
})