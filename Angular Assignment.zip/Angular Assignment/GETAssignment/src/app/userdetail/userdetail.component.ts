import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MainService } from '../users/main.service';
import { IUsers } from '../users/users.model';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {
  user:IUsers | undefined

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private _mainService:MainService
  ) { }


  getUser(id: number) {
    this._mainService.fetchOneUser(id)
    .subscribe(res => {
      this.user = res
    })
  }

  onBack(): void {
    this.router.navigate(['/users']);
  }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) {
      this.getUser(id);
    }
  }

}
