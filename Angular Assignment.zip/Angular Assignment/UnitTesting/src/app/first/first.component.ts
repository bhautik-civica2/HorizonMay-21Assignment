import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent {
  title:string = 'Unit Testing with Angular'

  constructor(private fb: FormBuilder) { }

  profileForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(15)]],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
    zip: ['', [Validators.required, Validators.pattern(/^[1-9][0-9]{5}$/)]]
  });

  private updateProfile() {
    this.profileForm.patchValue({
      name: 'bhautik',
      email: 'mba@gmail.com',
      phone: '08690872121',
      zip: '390002'
    });
  }

  onSubmit() {
    // debugger;
    console.log(this.profileForm.value);
  }

  privateExample() {
    this.updateProfile()
  }

}
