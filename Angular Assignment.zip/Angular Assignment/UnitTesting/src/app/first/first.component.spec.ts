import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing"
import {  ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { FirstComponent } from "./first.component"

fdescribe('first component test', () => {
  let component: FirstComponent;
  let fixture: ComponentFixture<FirstComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        FirstComponent
      ],
      imports: [
        BrowserModule,
        ReactiveFormsModule,
      ],
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(FirstComponent);
      component = fixture.componentInstance;
    })
  }));

  it('should create', waitForAsync(() => {
    expect(component).toBeTruthy();
  }));
  
  it('should test submit', waitForAsync(() => {
    //arrange
    component.profileForm.get('name')?.setValue('bhautik');
    component.profileForm.get('email')?.setValue('mba@gmail.com');
    component.profileForm.get('phone')?.setValue('08690872121');
    component.profileForm.get('zip')?.setValue('390002');

    //act
    component.onSubmit()

    //assert
    expect(component.profileForm.valid).toBeTruthy()
  }));

  it('positive result', waitForAsync(() => {
    //arrange
    component.profileForm.get('name')?.setValue('bhautik');

    //act
    component.onSubmit()

    //assert
    expect(component.profileForm.get('name')?.value).toBe('bhautik')
  }));

  it('negative result', waitForAsync(() => {
    //arrange
    component.profileForm.get('name')?.setValue('bhautik');
    component.profileForm.get('email')?.setValue('mba@gmail.com');
    component.profileForm.get('phone')?.setValue('08690872121');
    component.profileForm.get('zip')?.setValue('39000');

    //act
    component.onSubmit()

    //assert
    expect(component.profileForm.valid).toBeFalsy()
  }));

  xit('private method', waitForAsync(() => {
    //arrange
    component.profileForm.get('zip')?.setValue('390002');

    //act
    component.privateExample()

    //assert
    expect(component.profileForm.get('zip')?.value).toBe('364710')
  }));

  
})