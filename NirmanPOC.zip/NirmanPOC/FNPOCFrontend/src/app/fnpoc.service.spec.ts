import { TestBed } from '@angular/core/testing';

import { FnpocService } from './fnpoc.service';

describe('FnpocService', () => {
  let service: FnpocService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FnpocService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
