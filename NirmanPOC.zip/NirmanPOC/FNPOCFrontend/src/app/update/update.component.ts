import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition, MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CreateComponent } from '../create/create.component';
import { FnpocService } from '../fnpoc.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})

export class UpdateComponent implements OnInit {

  title:string = 'Update Trainer Form'

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  trainerList: any = []
  streamList: any = []
  specializationsList: any = []

  trainerForm: any

  constructor(private _fnpoc: FnpocService,
              private fb: FormBuilder,
              private http: HttpClient,
              private _snackBar: MatSnackBar,
              private router: Router,
              public dialog: MatDialogRef<CreateComponent>

            ) { }

  ngOnInit(): void {
    this.trainerForm = this.fb.group({
      trainerListId: [''],
      name: ['', [Validators.required]],
      stream: ['', [Validators.required]],
      specialization: [''],
      topic: ['', [Validators.required, Validators.pattern(/^(?!\s*$).+/)]]
    })

    this.getTrainer();
    this.getStream();
  }

  demoData() {
    this.trainerForm.patchValue({
      trainerListId: 1,
      name: '1',
      stream: '1',
      specialization: '1',
      topic: 'demo topic'
    })
  }

  get name(): any {
    return this.trainerForm.get('name');
  }

  get stream(): any {
    return this.trainerForm.get('stream');
  }

  get topic(): any {
    return this.trainerForm.get('topic');
  }

  topicErrorMessage() {
    if (this.topic.hasError('required')) {
      return 'Topic is required !';
    }

    return this.topic.hasError('pattern') ? 'Empty name is not valid' : ''
  }

  getTrainer() {
    this._fnpoc.fetchTrainer()
    .subscribe(res => {
      this.trainerList = res
    })
  }

  getStream() {
    this._fnpoc.fetchStream()
    .subscribe(res => {
      this.streamList = res
    })
  }

  onSelectStream(streamId: any) {
    if (streamId != null) {
      this._fnpoc.fetchSpecializationById(streamId)
      .subscribe(res => {
        this.specializationsList = res
      })
    } else {
      this.specializationsList = null
    }
  }

  openSnackBar(message: any, action: any) {
    const snackRef = this._snackBar.open(message, action, {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 2000
    });
  }

  onClose() {
    this.dialog.close();
    this._fnpoc.filter('Register Click');
  }


  updateTrainer() {
    if (this.trainerForm.valid == true) {
      console.warn(this.trainerForm.value)
    }
  }

}
