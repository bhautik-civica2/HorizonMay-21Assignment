import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { FnpocService } from '../fnpoc.service';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { CreateComponent } from '../create/create.component';
import { UpdateComponent } from '../update/update.component';

interface ITrainerList  {
  TrainerListId ?: number
  Name ?: string
  Stream ?: string
  Specialization : string
  Topic ?: string
}

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit, AfterViewInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  
  trainerList: any
  dataSource = new MatTableDataSource<ITrainerList>()

  constructor(private _fnpoc : FnpocService,
              private router: Router,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar
          ) { 
            this._fnpoc.listen()
            .subscribe((res: any) => {
              this.getSPViewTrainerList();
            })
          }

  
  ngOnInit(): void {
    this.getSPViewTrainerList()
  }

  getSPViewTrainerList() {
    this._fnpoc.fetchSPViewTrainerList()
    .subscribe(res => {
      this.trainerList = res as ITrainerList[]
      this.dataSource.data = this.trainerList
      
    })
  }

  displayedColumns: string[] = ['TrainerListId',
                                'Name',
                                'Stream',
                                'Specialization',
                                'Topic',
                                'Action'
                              ];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }  

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.disableClose = true;
    dialogConfig.width = "50%";
    
    const dialogRef = this.dialog.open(CreateComponent, dialogConfig);
  }

  openSnackBar(message: any) {
    let snackBarRef = this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 2000
    });
  }

  onDelete(id: number) {
    if(confirm('Are you want to delete ?')) {
      this._fnpoc.deleteTrainer(id)
      .subscribe(res => {
        this.openSnackBar(res);
        this.getSPViewTrainerList();
      })
    }
  }

  onEdit(trn: ITrainerList) {
    console.log(trn)



    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "50%";
    
    const dialogRef = this.dialog.open(UpdateComponent, dialogConfig);
  }

}
