import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FnpocService } from '../fnpoc.service';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import {MatDialogRef} from '@angular/material/dialog';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  title:string = 'Trainer Form'

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  trainerList: any = []
  streamList: any = []
  specializationsList: any = []

  trainerForm: any

  constructor(private _fnpoc: FnpocService,
              private fb: FormBuilder,
              private http: HttpClient,
              private _snackBar: MatSnackBar,
              private router: Router,
              public dialog: MatDialogRef<CreateComponent>

            ) { }

  ngOnInit(): void {
    this.trainerForm = this.fb.group({
      name: ['', [Validators.required]],
      stream: ['', [Validators.required]],
      specialization: [''],
      topic: ['', [Validators.required, Validators.pattern(/^(?!\s*$).+/)]]
    })

    this.getTrainer();
    this.getStream();
  }

  get name(): any {
    return this.trainerForm.get('name');
  }

  get stream(): any {
    return this.trainerForm.get('stream');
  }

  get topic(): any {
    return this.trainerForm.get('topic');
  }

  topicErrorMessage() {
    if (this.topic.hasError('required')) {
      return 'Topic is required !';
    }

    return this.topic.hasError('pattern') ? 'Empty name is not valid' : ''
  }

  getTrainer() {
    this._fnpoc.fetchTrainer()
    .subscribe(res => {
      this.trainerList = res
    })
  }

  getStream() {
    this._fnpoc.fetchStream()
    .subscribe(res => {
      this.streamList = res
    })
  }

  onSelectStream(streamId: any) {
    if (streamId != null) {
      this._fnpoc.fetchSpecializationById(streamId)
      .subscribe(res => {
        this.specializationsList = res
      })
    } else {
      this.specializationsList = null
    }
  }

  openSnackBar(message: any, action: any) {
    const snackRef = this._snackBar.open(message, action, {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 2000
    });
  }

  onClose() {
    this.dialog.close();
    this._fnpoc.filter('Register Click');
  }


  createTrainer() {
    if (this.trainerForm.valid == true) {
      console.log(this.trainerForm.value)
      this.http.post('https://localhost:44373/api/Trainer/createtrainer', this.trainerForm.value, {responseType: 'text'})
      .subscribe(res => {
        this.openSnackBar(res, 'Dismiss');
      }, error => {
        this.openSnackBar(JSON.parse(error.error).err.toString(), 'Ok');
      })
    }
  }

}
