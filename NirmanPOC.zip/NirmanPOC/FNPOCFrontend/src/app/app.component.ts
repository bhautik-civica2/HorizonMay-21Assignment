import { Component } from '@angular/core';

import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { CreateComponent } from './create/create.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FNPOCFrontend';

  constructor(public dialog: MatDialog) { }

  openDialog() {
    
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = "50%";
    
    const dialogRef = this.dialog.open(CreateComponent, dialogConfig);
  }
}
