import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

interface ITrainerList{
  TrainerListId ?: number
  Name ?: string
  Stream ?: string
  Specialization : string
  Topic ?: string
}

@Injectable({
  providedIn: 'root'
})
export class FnpocService {

  readonly _url:string = 'https://localhost:44373/api/Trainer'

  constructor(private http: HttpClient) { }

  fetchTrainer(): Observable<any[]> {
    return this.http.get<any[]>(`${this._url}/trainers`);
  }

  fetchStream(): Observable<any[]> {
    return this.http.get<any[]>(`${this._url}/streams`);
  }

  fetchSpecializationById(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${this._url}/specializations/${id}`);
  }

  fetchSPViewTrainerList() {
    return this.http.get<any[]>(`${this._url}/spViewTrainerList`);
  }

  deleteTrainer(id: number) {
    return this.http.delete(`${this._url}/deletetrainer/${id}`, {responseType: 'text'})
  }

  updateTrainer(trn: ITrainerList) {
    return this.http.put(`${this._url}/updatetrainer`, trn, {responseType: 'text'})
  }

  private _listners = new Subject<any>();
  
  listen(): Observable<any> {
    return this._listners.asObservable();
  }

  filter(filterBy: string) {
    this._listners.next(filterBy)
  }



  
}
