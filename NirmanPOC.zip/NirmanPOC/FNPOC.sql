
use FNPOC;

--select * from Trainers
--select * from Streams
--select * from Specializations

select * from TrainerLists TL order by TL.TrainerListId

--delete from TrainerLists
--DBCC CHECKIDENT ('TrainerLists', RESEED, 0)

--proc
go
create or alter proc spViewTrainerList
as
begin
	select TL.TrainerListId, T.TrainerName as Name, ST.StreamName as Stream, SP.SpecializationName as Specialization, TL.Topic
	from TrainerLists TL
	join Trainers T on T.TrainerId = TL.Name
	join Streams ST on ST.StreamId = TL.Stream
	left join Specializations SP on SP.SpecializationId = TL.Specialization
	order by TL.TrainerListId
end

exec spViewTrainerList

