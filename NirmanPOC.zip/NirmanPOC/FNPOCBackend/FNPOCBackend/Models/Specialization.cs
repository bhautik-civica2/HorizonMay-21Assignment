﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.Models
{
    public class Specialization
    {
        public int SpecializationId { get; set; }
        public string SpecializationName { get; set; }

        public int CurrentStreamId { get; set; }
        public Stream CurrentStream { get; set; }
    }
}
