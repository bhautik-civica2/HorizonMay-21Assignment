﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.Models
{
    public class TrainerDbContext : DbContext
    {
        public TrainerDbContext(DbContextOptions options) : base(options) { }

        public virtual DbSet<Trainer> Trainers { get; set; }
        public virtual DbSet<Stream> Streams { get; set; }
        public virtual DbSet<Specialization> Specializations { get; set; }
        public virtual DbSet<TrainerList> TrainerLists { get; set; }
        public virtual DbSet<spViewTrainerList> SpViewTrainerLists { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Trainer>()
                        .HasAlternateKey(ak => ak.TrainerName);

            modelBuilder.Entity<Stream>()
                        .HasAlternateKey(ak => ak.StreamName);

            modelBuilder.Entity<Specialization>()
                        .HasOne(a => a.CurrentStream)
                        .WithMany(b => b.Specializations)
                        .HasForeignKey(fk => fk.CurrentStreamId)
                        .IsRequired();

            modelBuilder.Entity<TrainerList>()
                        .HasAlternateKey(cak => new { cak.Name, cak.Stream, cak.Specialization });


            modelBuilder.Entity<Trainer>().HasData(
               new Trainer() { TrainerId = 1, TrainerName = "Hitesh Prajapati" },
               new Trainer() { TrainerId = 2, TrainerName = "Amjad Shekh" },
               new Trainer() { TrainerId = 3, TrainerName = "Devendra Patel" },
               new Trainer() { TrainerId = 4, TrainerName = "Jitendra Mhaskar" },
               new Trainer() { TrainerId = 5, TrainerName = "Jitendra Joshi" },
               new Trainer() { TrainerId = 6, TrainerName = "Mihir Suthar" },
               new Trainer() { TrainerId = 7, TrainerName = "Nishant Patel" },
               new Trainer() { TrainerId = 8, TrainerName = "Dipak Misal" }
               );

            modelBuilder.Entity<Stream>().HasData(
               new Stream() { StreamId = 1, StreamName = "SE" },
               new Stream() { StreamId = 2, StreamName = "QA" },
               new Stream() { StreamId = 3, StreamName = "BA" },
               new Stream() { StreamId = 4, StreamName = "Infra" }
               );

            modelBuilder.Entity<Specialization>().HasData(
              new Specialization() { SpecializationId = 1, SpecializationName = ".Net", CurrentStreamId = 1 },
              new Specialization() { SpecializationId = 2, SpecializationName = "Angular", CurrentStreamId = 1 },
              new Specialization() { SpecializationId = 3, SpecializationName = "React", CurrentStreamId = 1 },
              new Specialization() { SpecializationId = 4, SpecializationName = "Automation", CurrentStreamId = 2 },
              new Specialization() { SpecializationId = 5, SpecializationName = "Performance", CurrentStreamId = 2 },
              new Specialization() { SpecializationId = 6, SpecializationName = "Penetration", CurrentStreamId = 2 }
              );
        }

    }
}
