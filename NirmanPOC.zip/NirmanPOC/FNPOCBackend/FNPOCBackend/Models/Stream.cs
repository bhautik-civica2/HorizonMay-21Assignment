﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.Models
{
    public class Stream
    {
        public int StreamId { get; set; }
        [Required]
        public string StreamName { get; set; }

        public List<Specialization> Specializations { get; set; }
    }
}
