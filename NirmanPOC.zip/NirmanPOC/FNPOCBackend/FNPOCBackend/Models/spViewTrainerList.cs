﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.Models
{
    [Keyless]
    public class spViewTrainerList
    {
        public int TrainerListId { get; set; }
        public string Name { get; set; }
        public string Stream { get; set; }
        public string Specialization { get; set; }
        public string Topic { get; set; }
    }
}
