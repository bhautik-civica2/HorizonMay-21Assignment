﻿using FNPOCBackend.Repository;
using FNPOCBackend.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FNPOCBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainerController : ControllerBase
    {
        ITrainerRepo trainerRepo;
        public TrainerController(ITrainerRepo _trainerRepo)
        {
            trainerRepo = _trainerRepo;
        }

        [HttpGet("trainers")]
        public IActionResult GetAllTrainer()
        {
            return Ok(trainerRepo.GetTrainer());
        }

        [HttpGet("streams")]
        public IActionResult GetAllStream()
        {
            return Ok(trainerRepo.GetStream());
        }

        [HttpGet("specializations/{id}")]
        public IActionResult GetAllSpecialization(int? id)
        {
            return Ok(trainerRepo.GetSpecializationById(id));
        }

        [HttpPost("createtrainer")]
        public ActionResult Post([FromBody] TrainerListViewModel model)
        {
            try
            {
                trainerRepo.AddTrainer(model);
                return StatusCode(StatusCodes.Status201Created, "Trainer Created Successfully");
            }
            catch
            {
                ModelState.AddModelError("err", "Please Select Another Combination");
                return BadRequest(ModelState);
            }
        }

        [HttpGet("spViewTrainerList")]
        public IActionResult GetAllTrainerList()
        {
            return Ok(trainerRepo.GetTrainerList());
        }

        [HttpGet("trainerList{id}")]
        public IActionResult GetSingleTrainerList(int? id)
        {
            return Ok(trainerRepo.GetTrainerListById(id));
        }

        [HttpDelete("deletetrainer/{id}")]
        public IActionResult Delete(int id)
        {
            var trn = trainerRepo.GetTrainerListById(id);
            if (trn == null)
            {
                return NotFound();
            }
            if (id > 0)
            {
                trainerRepo.DeleteTrainer(id);
                return Ok("Trianer Deleted SuccessFully");
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut("updatetrainer/{id}")]
        public IActionResult Put(int id, [FromBody] TrainerListViewModel model)
        {
            var trn = trainerRepo.GetTrainerListById(id);
            if (trn == null)
            {
                return NotFound();
            }
            trn.TrainerListId = model.TrainerListId;
            trn.Name = model.Name;
            trn.Stream = model.Stream;
            trn.Specialization = model.Specialization;
            trn.Topic = model.Topic;

            trainerRepo.UpdateTrainer(trn);
            return Ok("Trainer Updated Successfully");
        }
    }
}
