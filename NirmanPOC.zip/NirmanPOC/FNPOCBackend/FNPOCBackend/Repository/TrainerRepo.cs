﻿using FNPOCBackend.Models;
using FNPOCBackend.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.Repository
{
    public class TrainerRepo : ITrainerRepo
    {
        TrainerDbContext db;
        public TrainerRepo(TrainerDbContext _db)
        {
            db = _db;
        }

        public List<TrainerViewModel> GetTrainer()
        {
            if (db != null)
            {
                return (from e in db.Trainers
                        select new TrainerViewModel
                        {
                            TrainerId = e.TrainerId,
                            TrainerName = e.TrainerName
                        }).ToList();
            }
            return null;
        }

        public List<StreamViewModel> GetStream()
        {
            if (db != null)
            {
                return (from e in db.Streams
                        select new StreamViewModel
                        {
                            StreamId = e.StreamId,
                            StreamName = e.StreamName
                        }).ToList();
            }
            return null;
        }

        public List<SpecializationViewModel> GetSpecializationById(int? id)
        {
            if (db != null)
            {
                return (from e in db.Specializations
                        where e.CurrentStreamId == id
                        select new SpecializationViewModel
                        {
                            SpecializationId = e.SpecializationId,
                            SpecializationName = e.SpecializationName,
                            CurrentStreamId = e.CurrentStreamId
                        }).ToList();
            }
            return null;
        }

        public int AddTrainer(TrainerListViewModel tl)
        {
            if (db != null)
            {
                var trn = new TrainerList
                {
                    TrainerListId = tl.TrainerListId,
                    Name = tl.Name,
                    Stream = tl.Stream,
                    Specialization = tl.Specialization,
                    Topic = tl.Topic
                };
                db.TrainerLists.Add(trn);
                db.SaveChanges();

                return trn.TrainerListId;
            }
            return 0;
        }

        public List<spViewTrainerList> GetTrainerList()
        {
            var trainer = db.SpViewTrainerLists.FromSqlRaw($"EXEC spViewTrainerList")
                                .ToListAsync().Result
                                .ToList();
            return trainer;
        }

        public TrainerListViewModel GetTrainerListById(int? id)
        {
            if (db != null)
            {
                return (from e in db.TrainerLists
                        where e.TrainerListId == id
                        select new TrainerListViewModel
                        {
                            TrainerListId = e.TrainerListId,
                            Name = e.Name,
                            Stream = e.Stream,
                            Specialization = e.Specialization,
                            Topic = e.Topic
                        }).FirstOrDefault();
            }
            return null;
        }

        public void DeleteTrainer(int? id)
        {
            if (db != null)
            {
                var trn = (from e in db.TrainerLists
                           where e.TrainerListId == id
                           select e
                           ).FirstOrDefault();
                db.TrainerLists.Remove(trn);
                db.SaveChanges();
            }
        }

        public void UpdateTrainer(TrainerListViewModel trn)
        {
            if (db != null)
            {
                var nTrn = new TrainerList
                {
                    TrainerListId = trn.TrainerListId,
                    Name = trn.Name,
                    Stream = trn.Stream,
                    Specialization = trn.Specialization,
                    Topic = trn.Topic
                };
                db.TrainerLists.Update(nTrn);
                db.SaveChanges();
            }
        }

    }
}
