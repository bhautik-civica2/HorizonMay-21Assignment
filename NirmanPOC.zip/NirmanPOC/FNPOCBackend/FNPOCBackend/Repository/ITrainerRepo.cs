﻿using FNPOCBackend.Models;
using FNPOCBackend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.Repository
{
    public interface ITrainerRepo
    {
        List<TrainerViewModel> GetTrainer();
        List<StreamViewModel> GetStream();
        List<SpecializationViewModel> GetSpecializationById(int? id);
        int AddTrainer(TrainerListViewModel tl);
        List<spViewTrainerList> GetTrainerList();
        TrainerListViewModel GetTrainerListById(int? id);
        void DeleteTrainer(int? id);
        void UpdateTrainer(TrainerListViewModel trn);


    }
}
