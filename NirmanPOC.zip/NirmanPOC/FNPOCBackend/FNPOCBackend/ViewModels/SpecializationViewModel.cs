﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.ViewModels
{
    public class SpecializationViewModel
    {
        public int SpecializationId { get; set; }
        public string SpecializationName { get; set; }
        public int CurrentStreamId { get; set; }
    }
}
