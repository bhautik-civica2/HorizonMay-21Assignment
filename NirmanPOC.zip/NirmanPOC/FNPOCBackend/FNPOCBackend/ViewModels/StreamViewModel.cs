﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FNPOCBackend.ViewModels
{
    public class StreamViewModel
    {
        public int StreamId { get; set; }
        public string StreamName { get; set; }
    }
}
